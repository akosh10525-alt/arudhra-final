pip install streamlit
pip install pyPDF2

streamlit run app.py